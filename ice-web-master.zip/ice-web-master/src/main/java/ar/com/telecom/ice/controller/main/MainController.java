package ar.com.telecom.ice.controller.main;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller 
public class MainController {

	@RequestMapping(value = "/main", method = RequestMethod.GET)
	public String main(ModelMap model) {
		return "main";
	}
	
	@RequestMapping(value = "main/template/header", method = RequestMethod.GET)
	public String header(ModelMap model) {
		return "template/header";
	}
	
	@RequestMapping(value = "/main/content/bancos", method = RequestMethod.GET)
	public String bancos(ModelMap model) {
		return "content/bancos";
	}
	
	@RequestMapping(value = "main/content/ctrl-archivo", method = RequestMethod.GET)
	public String ctrlArchivo(ModelMap model) {
		return "content/ctrl-archivo";
	}
	
	@RequestMapping(value = "main/content/ctrl-op-online-resumen", method = RequestMethod.GET)
	public String opOnlineResumen(ModelMap model) {
		return "content/ctrl-op-online-resumen";
	}
	
	@RequestMapping(value = "main/content/ctrl-op-online-detalle", method = RequestMethod.GET)
	public String opOnlineDetalle(ModelMap model) {
		return "content/ctrl-op-online-detalle";
	}
	
	@RequestMapping(value = "main/content/ctrl-imputacion-resumen", method = RequestMethod.GET)
	public String impResumen(ModelMap model) {
		return "content/ctrl-imputacion-resumen";
	}
	
	@RequestMapping(value = "main/content/ctrl-imputacion-detalle", method = RequestMethod.GET)
	public String impDetalle(ModelMap model) {
		return "content/ctrl-imputacion-detalle";
	}
	
	@RequestMapping(value = "main/content/ctrl-total-facturacion", method = RequestMethod.GET)
	public String totalFacturacion(ModelMap model) {
		return "content/ctrl-total-facturacion";
	}
	
	@RequestMapping(value = "main/content/ctrl-remesa", method = RequestMethod.GET)
	public String remesa(ModelMap model) {
		return "content/ctrl-remesa";
	}
	
	@RequestMapping(value = "main/content/configuracion", method = RequestMethod.GET)
	public String configuracion(ModelMap model) {
		return "content/configuracion";
	}
	
	@RequestMapping(value = "main/content/404", method = RequestMethod.GET)
	public String error(ModelMap model) {
		return "content/404";
	}
	
}