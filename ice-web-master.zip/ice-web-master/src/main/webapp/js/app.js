//
// main ice web application
//
var app = angular.module('ice-web', ['ngRoute']);

//
// route provider
//
app.config(function($routeProvider, $locationProvider) {
	$routeProvider
    .when('/', { templateUrl : 'content/bancos' })
    .when('/bancos', { templateUrl : 'content/bancos' })
		.when('/ctrl-archivo', { templateUrl : 'content/ctrl-archivo' })
		.when('/ctrl-op-online-resumen', { templateUrl : 'content/ctrl-op-online-resumen' })
		.when('/ctrl-op-online-detalle', { templateUrl : 'content/ctrl-op-online-detalle' })
		.when('/ctrl-imputacion-resumen', { templateUrl : 'content/ctrl-imputacion-resumen' })
		.when('/ctrl-imputacion-detalle', { templateUrl : 'content/ctrl-imputacion-detalle' })
		.when('/ctrl-total-facturacion', { templateUrl : 'content/ctrl-total-facturacion' })
		.when('/ctrl-remesa', { templateUrl : 'content/ctrl-remesa' })
    .when('/configuracion', { templateUrl : 'content/configuracion' });
});
