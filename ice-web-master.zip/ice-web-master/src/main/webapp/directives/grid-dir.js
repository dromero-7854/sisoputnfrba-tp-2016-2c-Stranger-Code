app.directive('grid', function ($http) {
  return {
    restrict: 'A',
    scope: {
      gridSettings: '='
    },
    link: function (scope, elem, attrs) {
      $http.get(scope.gridSettings.urlData).then(function (response) {
        if (angular.isDefined(scope.gridSettings.childGrid)) {
          var parentKey = scope.gridSettings.childGrid.parentDSField;
          var childKey = scope.gridSettings.childGrid.childDSField;
          var queryField = scope.gridSettings.childGrid.queryField;
          scope.gridSettings.dataSource = response.data[parentKey];
          scope.gridSettings.childGrid.dataSource = response.data[childKey];
          scope.gridSettings.childGrid.queryString = queryField;
        } else {
          scope.gridSettings.dataSource = response.data;
        }
        $(elem).ejGrid(scope.gridSettings);
      });
    }
  }
});
