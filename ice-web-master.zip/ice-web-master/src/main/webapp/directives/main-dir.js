app.directive('main', function ($location) {
  return {
    restrict: 'A',
    link: function (scope, elem, attrs) {

      var activeLink = function () {
        $('#sidebar-wrapper li').each(function (index, element) {
          $(element).removeClass('active').css('background-color', '');;
        });
        var hrefs = [ '/#' + scope.path, '#' + scope.path, scope.path ];
        var li;
        var ul;
        // sidebar-nav active links
        angular.forEach($('#sidebar-nav a'), function (a) {
          a = angular.element(a);
          if (hrefs.indexOf(a.attr('href')) !== -1) {
            li = a.parent();
          };
        });
        if (!angular.isUndefined(li)) {
          li.addClass('active');
          ul = li.closest('ul');
          if (ul.hasClass('collapseable')) {
            ul.parent().addClass('active').css('background-color', '#293846');
            ul.collapse('show');
          } else {
            $('#sidebar-nav ul.collapseable').collapse('hide');
          }
        }
        // sidebar-nav-collapsed active links
        angular.forEach($('#sidebar-nav-collapsed a'), function (a) {
          a = angular.element(a);
          if (hrefs.indexOf(a.attr('href')) !== -1) {
            li = a.parent();
          };
        });
        if (!angular.isUndefined(li)) {
          li.addClass('active');
          ul = li.closest('ul');
          if (ul.hasClass('menu-list')) {
            ul.parent().addClass('active');
          }
        }
      }

      $('.collapseable').on('hide.bs.collapse', function () {
        var isActive = false;
        $(this).find('li').each(function (index, li) {
          if ($(li).hasClass('active')) {
            isActive = true;
            return false;
          }
        });
        $(this).parent().css('background-color', '');
        if (!isActive) $(this).parent().removeClass('active');
      });

      $('.collapseable').on('show.bs.collapse', function () {
        $(this).parent().addClass('active').css('background-color', '#293846');
        $('.collapseable').not($(this)).each(function (index, menu) {
          $(menu).collapse('hide');
        });
      });

      scope.$on('$routeChangeSuccess', function () {
        scope.path = $location.path();
        activeLink();
      });

      $('#toggle-main-menu').on('click', function(event) {
        event.stopPropagation();
        $(this).find('i').toggleClass('fa-chevron-right fa-chevron-left')
        $('.e-grid').ejGrid('refreshContent');
        if ($('#wrapper').hasClass('menu-displayed')) {
          $('#ice-logo').removeClass('ice-logo').addClass('ice-logo-min');
          $('#profile-sidebar').hide();
          $('#sidebar-nav').hide();
          $('#sidebar-nav .collapseable').collapse('hide');
          $('#sidebar-nav-collapsed').show();
          $('#wrapper').removeClass('menu-displayed').addClass('menu-hidden');
        } else if ($('#wrapper').hasClass('menu-hidden')){
          $('#ice-logo').removeClass('ice-logo-min').addClass('ice-logo');
          $('#profile-sidebar').show();
          $('#sidebar-nav').show();
          $('#sidebar-nav-collapsed').hide();
          $('#wrapper').removeClass('menu-hidden').addClass('menu-displayed');
          activeLink();
        }

      });
    }
  }
});
