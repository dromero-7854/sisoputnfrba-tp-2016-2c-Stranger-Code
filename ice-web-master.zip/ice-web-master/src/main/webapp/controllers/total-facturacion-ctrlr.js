//
// total facturacion > controller
//
app.controller('total-facturacion-ctrlr', function ($scope, $http, dummyService, urlMappingUtil) {
  $scope.gridSettings = {
    urlData: urlMappingUtil.dummy.data,
    allowSorting : true,
    allowPaging : true,
    columns : [
      { field : "entidad", headerText : "Entidad" },
      { field : "fechaProceso", headerText : "Fecha proceso" },
      { field : "fechaICE", headerText : "Fecha ICE" },
      { field : "archivo", headerText : "Archivo" }
    ],
    childGrid: {
      parentDSField: "resumen",
      childDSField: "detalle",
      queryField: "idDetalle",
      allowPaging: false,
      allowResizing: true,
      allowResizeToFit : true,
      allowScrolling : true,
      showStackedHeader: true,
      allowGrouping : true,
      groupSettings: { showGroupedColumn:false, showDropArea: false, groupedColumns: ["empresa","operacion","sistema"] },
      stackedHeaderRows: [{ stackedHeaderColumns: [
        { headerText: "", column: "empresa,operacion,sistema,identificador" },
        { headerText: "Operaciones recibidas", column: "oper-cantidad,oper-importe", textAlign: "center" },
        { headerText: "", column: "diferencia" }]
      }],




      showSummary: true,
      summaryRows: [{
          summaryColumns: [{
              summaryType: ej.Grid.SummaryType.Sum,
              displayColumn: "oper-cantidad",
              dataMember: "oper-cantidad",
              format: "{0:C2}",
              prefix: "Sum = "
          }],
          showTotalSummary: false
      }],



      columns: [
        { field : "empresa", headerText : "Empresa" },
        { field : "operacion", headerText : "Operacion" },
        { field : "sistema", headerText : "Sistema" },
        { field : "identificador", headerText : "Identificador" },
        { field : "oper-cantidad", headerText : "Cantidad", width: 100, headerTextAlign : "center", textAlign : "right" },
        { field : "oper-importe", headerText : "Importe", width: 100, headerTextAlign : "center", textAlign : "right" },
        { field : "diferencia", headerText : "Diferencia recibido imputado", width: 200, headerTextAlign : "right", textAlign : "right" }
      ]
    },
  };
});
