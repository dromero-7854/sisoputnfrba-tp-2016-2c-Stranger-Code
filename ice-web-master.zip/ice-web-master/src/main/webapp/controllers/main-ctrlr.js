//
// main > controller
//
app.controller('main-ctrlr', function ($scope, $location, $http) {

});
