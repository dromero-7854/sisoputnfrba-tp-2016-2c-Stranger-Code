app.factory('urlMappingUtil', function () {
	return {
		dummy: {
			data: '../data-dummy/ctrl-imputacion-agrup.json'
		}
	};
});
