app.factory('dummyService', function ($http, urlMappingUtil) {
  return {
    getData: function() {
      $http.get(urlMappingUtil.dummy.data).then(function(response) {
        return response.data;
      });
    }
  };
});
