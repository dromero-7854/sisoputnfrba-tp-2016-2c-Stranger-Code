package edu.tecso.crud.service;

import java.util.List;

import edu.tecso.crud.exception.BusinessException;
import edu.tecso.crud.model.Account;

public interface AccountService {
	
	public Account save(Account account);
	
	public void deleteById(Integer id) throws BusinessException;
	
	public List<Account> findAll();

}
