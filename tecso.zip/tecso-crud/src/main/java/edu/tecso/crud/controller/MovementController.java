package edu.tecso.crud.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.tecso.crud.model.Movement;
import edu.tecso.crud.service.MovementService;

@RestController
@RequestMapping("/api")
public class MovementController {

	private final Logger log = LoggerFactory.getLogger(MovementController.class);
		
	@Autowired
	private MovementService movementService;
		
	@PostMapping("/add-movement")
    ResponseEntity<Movement> createAccount(@Valid @RequestBody Movement movement) throws URISyntaxException {
        log.info("Request to create account: {}", movement);
        Movement result = movementService.save(movement);
        return ResponseEntity.created(new URI("/api/account/" + result.getId())).body(result);
    }
	
	@GetMapping("/find-account-movements/{accountId}")
	ResponseEntity<List<Movement>> findAccountMovements(@PathVariable Integer accountId) {
		return ResponseEntity.ok().body(movementService.findAccountMovements(accountId));
	}
	
}
